const express = require('express');
const bodyParser = require('body-parser');
const visitorLogsRoutes = require('./routes/visitorLogs');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use('/api/visitor_logs', visitorLogsRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});