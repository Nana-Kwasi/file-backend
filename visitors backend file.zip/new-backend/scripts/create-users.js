
require('dotenv').config();
const pool = require('../db');

async function createUsersTable() {
  try {
    // Check if users_table exists
    const tableCheck = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users_table'
      );
    `);
    
    if (!tableCheck.rows[0].exists) {
      console.log('Creating users_table...');
      
      await pool.query(`
        CREATE TABLE users_table (
          id SERIAL PRIMARY KEY,
          email VARCHAR(255) UNIQUE NOT NULL,
          password VARCHAR(255) NOT NULL,
          branch VARCHAR(100) NOT NULL,
          role VARCHAR(50) DEFAULT 'user',
          created_at TIMESTAMP DEFAULT NOW(),
          last_login TIMESTAMP
        );
      `);
      
      console.log('users_table created successfully');
    } else {
      console.log('users_table already exists');
    }
  } catch (err) {
    console.error('Error creating users_table:', err);
  } finally {
    pool.end();
  }
}

createUsersTable();