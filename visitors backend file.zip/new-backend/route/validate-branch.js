
router.post('/validate-branch', authMiddleware, async (req, res) => {
    const { email, branch } = req.body;
  
    try {
      
      const userResult = await pool.query(
        'SELECT branches FROM admin_users WHERE email = $1', 
        [email]
      );
  
      if (userResult.rows.length === 0) {
        return res.status(403).json({ error: 'User not found' });
      }
  
      const userBranches = userResult.rows[0].branches;
  
      if (!userBranches || !userBranches.includes(branch)) {
        return res.status(403).json({ error: 'Branch access denied' });
      }
  
      res.json({ message: 'Branch access validated' });
    } catch (err) {
      console.error('Branch validation error:', err);
      res.status(500).json({ error: 'Server error during branch validation' });
    }
  });