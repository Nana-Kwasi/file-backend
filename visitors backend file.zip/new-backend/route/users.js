
const express = require('express');
const router = express.Router();
const usersController = require('../controllers/Users Controller')
const authMiddleware = require('../middleware/auth'); 


router.post('/verify-fnumber', authMiddleware, usersController.verifyFnumber);

router.post('/', authMiddleware, usersController.createUser);
router.post('/authenticate', usersController.authenticateUser);
router.post('/verify2fa', usersController.verify2FA);
router.post('/finalize-login', usersController.finalizeLogin);
router.post('/checkUserBranches', usersController.checkUserBranches);
router.post('/track2FAStatus', usersController.track2FAStatus);




router.get('/', authMiddleware, usersController.getAllUsers);


router.put('/:id', authMiddleware, usersController.updateUser);


router.delete('/:id', authMiddleware, usersController.deleteUser);

module.exports = router;