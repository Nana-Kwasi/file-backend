
//route for auth

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.post('/login', authController.login);
router.post('/register', authController.registerUser);
router.post('/verify', authController.verifyToken);
router.post('/verify-admin', authController.verifyAdminCredentials);

module.exports = router