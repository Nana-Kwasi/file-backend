
//routh for visitor
// const express = require('express');
// const router = express.Router();
// const visitorsController = require('../controllers/visitorsLogsController');



// // Existing routes
// router.get('/by-phone', visitorsController.getVisitorLogsByPhoneNumber);
// router.get('/:id', visitorsController.getVisitorLogById);
// router.post('/', visitorsController.createVisitorLog);
// router.put('/:id', visitorsController.updateVisitorLog);
// router.delete('/:id', visitorsController.deleteVisitorLog);
// router.get('/check-telephone/:telephone', visitorsController.checkTelephoneExists);




const express = require('express');
const router = express.Router();
const visitorsController = require('../controllers/visitorsLogsController');



router.get('/check-telephone/:telephone', visitorsController.checkTelephoneExists);
router.get('/index', visitorsController.getAllBranches);
router.get('/index/branch', visitorsController.getVisitorLogsByBranchCode);
router.get('/', visitorsController.getAllVisitorLogs);
// Other existing routes
router.get('/by-phone', visitorsController.getVisitorLogsByPhoneNumber);
router.get('/:id', visitorsController.getVisitorLogById);
router.post('/', visitorsController.createVisitorLog);
router.put('/:id', visitorsController.updateVisitorLog);
router.delete('/:id', visitorsController.deleteVisitorLog);

module.exports = router;